/* ------------------------------------------------------
   Auteur : Collignon Rémi
   			Morvan Guy-Yann
   	Header Fonction lettresTheta
-----------------------------------------------------*/
#ifndef LETTRESTHETA
#define LETTRESTHETA

	#include <stdlib.h>
	#include <math.h>
	#include <stdio.h>

	#define L1 175
	#define L2 160
	#define L3 160

   	void lettresTheta(float* tx, float* ty, float* tz, int np, float* tt1, float* tt2, float* tt3);


#endif
