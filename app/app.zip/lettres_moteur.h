/* ------------------------------------------------------
   Auteur : Collignon Rémi
   			Morvan Guy-Yann
   	Header Fonction lettresMoteur
   	-----------------------------------------------------*/

   	#ifndef LETTRESMOTEUR
   	#define LETTRESMOTEUR 
   		void lettresMoteur(float* tt1, float* tt2, float* TT3, int* ttr, int np);
   	#endif