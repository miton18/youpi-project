/* ------------------------------------------------------
   Auteur : Collignon Rémi
   			Morvan Guy-Yann
   	Fonction calcul
   	Addition de deux entier
   	-----------------------------------------------------*/
#include "calcul.h"

int calcul(int e1, int e2)
{
	int resultat = 0;
	resultat = e1 + e2;

	return resultat;

}
