/* ------------------------------------------------------
   Auteur : Collignon Rémi
   			Morvan Guy-Yann
   	Fonction calcul
   	Addition de deux entier
   	-----------------------------------------------------*/
#include "calcul.h"

/*Fonction calcul
      paramètre : int e1: premier nombre
      			  int e2: second nombre
      retour : int resultat : resultat de l'addition de e1 et e2 
*/
int calcul(int e1, int e2)
{
	int resultat = 0;
	resultat = e1 + e2;

	return resultat;

}
