/* ------------------------------------------------------
   Auteur : Collignon Rémi
   			Morvan Guy-Yann
   	Déclaration dans include nécessaire
   	-----------------------------------------------------*/
#ifndef DECLARATION_H
#define DECLARATION_H

	#include <stdio.h>
	#include "calcul.h"
	#include "ihm.h"
	#include "conversion.h"
	#include "lettres_xyz.h"
	#include "lettres_theta.h"
	#include "lettres_moteur.h"
	#include "ecriture_traj.h"
	#include "window.h"
#endif
