#include "ihm.h"
#include <stdio.h>

int main() {

	int e1, e2;
	ihm(&e1, &e2);

	printf("\nVALEUR DE RETOUR: e1: %d e2: %d\n", e1, e2);
}
